class BST {
    private BTNode root;

    BST(){
        this.root=null;
    }

    /**
     * @return the root
     */
    protected BTNode getRoot() {
        return root;
    }

    /**
     * @param root the root to set
     */
    protected void setRoot(BTNode root) {
        this.root = root;
    }



}